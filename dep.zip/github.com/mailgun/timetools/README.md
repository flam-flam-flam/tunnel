**This repo is deprecated, functionality has moved to http://github.com/mailgun/holster (See Clock)**

timetools
=========

Go library with various time utilities used at Mailgun.
